package com.blackumor.jibe.Storage;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.blackumor.jibe.Storage.QuestionsContract.LatestQuestions;
import com.blackumor.jibe.Storage.QuestionsContract.TrendingQuestions;
import com.blackumor.jibe.Storage.QuestionsContract.InterestedQuestions;

import java.util.HashMap;

/**
 * Created by Rohan on 11-08-2015.
 */
public class QuestionsDBAdapter{

    LatestQuestionsDBHelper latestQuestionsDBHelper;
    TrendingQuestionsDBHelper trendingQuestionsDBHelper;
    InterestedQuestionsDBHelper interestedQuestionsDBHelper;
    Context context;

    public void initialize(Context context) {
        latestQuestionsDBHelper = new LatestQuestionsDBHelper(context);
        trendingQuestionsDBHelper = new TrendingQuestionsDBHelper(context);
        interestedQuestionsDBHelper = new InterestedQuestionsDBHelper(context);
    }

    public QuestionsDBAdapter(Context context) {
        this.context = context;
    }

    public long insertLatestQuestionsData(String id, String user_id, String user_name, String user_image,
                                           String title, String time, String likes,
                                           String follows, String answers) {
        SQLiteDatabase dbWriteable = latestQuestionsDBHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(LatestQuestions.COLUMN_NAME_QUESTION_ID, id);
        values.put(LatestQuestions.COLUMN_NAME_USER_ID, user_id);
        values.put(LatestQuestions.COLUMN_NAME_USER_NAME, user_name);
        values.put(LatestQuestions.COLUMN_NAME_USER_IMAGE, user_image);
        values.put(LatestQuestions.COLUMN_NAME_TITLE, title);
        values.put(LatestQuestions.COLUMN_NAME_TIMESTAMP, time);
        values.put(LatestQuestions.COLUMN_NAME_LIKES, likes);
        values.put(LatestQuestions.COLUMN_NAME_FOLLOWS, follows);
        values.put(LatestQuestions.COLUMN_NAME_ANSWERS, answers);

        long newRowId = dbWriteable.insert(LatestQuestions.TABLE_NAME, null, values);
        return newRowId;
    }

    public HashMap<String, String> getParticularLatestQuestion(int position) {

        int next_position = position;
        String[] allColumns = {
                LatestQuestions._ID,
                LatestQuestions.COLUMN_NAME_QUESTION_ID,
                LatestQuestions.COLUMN_NAME_USER_ID,
                LatestQuestions.COLUMN_NAME_USER_NAME,
                LatestQuestions.COLUMN_NAME_USER_IMAGE,
                LatestQuestions.COLUMN_NAME_TITLE,
                LatestQuestions.COLUMN_NAME_TIMESTAMP,
                LatestQuestions.COLUMN_NAME_LIKES,
                LatestQuestions.COLUMN_NAME_FOLLOWS,
                LatestQuestions.COLUMN_NAME_ANSWERS
        };

        SQLiteDatabase db = latestQuestionsDBHelper.getWritableDatabase();
        String query_text = LatestQuestions._ID + "=" + next_position;

        Cursor cursor = db.query(LatestQuestions.TABLE_NAME, allColumns, query_text, null, null, null, null);
        cursor.moveToFirst();

        String id = String.valueOf(cursor.getInt(0));
        String q_id = cursor.getString(1);
        String u_id = cursor.getString(2);
        String u_name = cursor.getString(3);
        String u_image = cursor.getString(4);
        String title = cursor.getString(5);
        String time = cursor.getString(6);
        String likes = cursor.getString(7);
        String follows = cursor.getString(8);
        String answers = cursor.getString(9);

        HashMap<String, String> question = new HashMap<>();

        question.put("id", id);
        question.put("q_id", q_id);
        question.put("u_id", u_id);
        question.put("u_name", u_name);
        question.put("u_image", u_image);
        question.put("title", title);
        question.put("time", time);
        question.put("likes", likes);
        question.put("follows", follows);
        question.put("answers", answers);
        cursor.close();

        return question;
    }


    public void invalidateLatestQuestionsDatabase(){
        latestQuestionsDBHelper.invalidData(latestQuestionsDBHelper.getWritableDatabase());
    }


    public long getLatestQuestionsCount() {
        SQLiteDatabase db = latestQuestionsDBHelper.getReadableDatabase();
        long count = DatabaseUtils.queryNumEntries(db, LatestQuestions.TABLE_NAME);
        return count;
    }


    public int getInverseLatestQuestions(int position) {
        int count = (int)getLatestQuestionsCount();
        return count - position;
    }





















    public long insertTrendingQuestionsData(String id, String user_id, String user_name, String user_image,
                                           String title, String time, String likes,
                                           String follows, String answers) {

        SQLiteDatabase dbWriteable = trendingQuestionsDBHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TrendingQuestions.COLUMN_NAME_QUESTION_ID, id);
        values.put(TrendingQuestions.COLUMN_NAME_USER_ID, user_id);
        values.put(TrendingQuestions.COLUMN_NAME_USER_NAME, user_name);
        values.put(TrendingQuestions.COLUMN_NAME_USER_IMAGE, user_image);
        values.put(TrendingQuestions.COLUMN_NAME_TITLE, title);
        values.put(TrendingQuestions.COLUMN_NAME_TIMESTAMP, time);
        values.put(TrendingQuestions.COLUMN_NAME_LIKES, likes);
        values.put(TrendingQuestions.COLUMN_NAME_FOLLOWS, follows);
        values.put(TrendingQuestions.COLUMN_NAME_ANSWERS, answers);

        long newRowId = dbWriteable.insert(TrendingQuestions.TABLE_NAME, null, values);
        return newRowId;
    }

    public void invalidateTrendingQuestionsDatabase(){
        trendingQuestionsDBHelper.invalidData(trendingQuestionsDBHelper.getWritableDatabase());
    }

    public long getTrendingQuestionsCount() {
        SQLiteDatabase db = trendingQuestionsDBHelper.getReadableDatabase();
        long count = DatabaseUtils.queryNumEntries(db, TrendingQuestions.TABLE_NAME);
        return count;
    }

    public HashMap<String, String> getParticularTrendingQuestion(int position) {

        int next_position = position + 1;
        String[] allColumns = {
                TrendingQuestions._ID,
                TrendingQuestions.COLUMN_NAME_QUESTION_ID,
                TrendingQuestions.COLUMN_NAME_USER_ID,
                TrendingQuestions.COLUMN_NAME_USER_NAME,
                TrendingQuestions.COLUMN_NAME_USER_IMAGE,
                TrendingQuestions.COLUMN_NAME_TITLE,
                TrendingQuestions.COLUMN_NAME_TIMESTAMP,
                TrendingQuestions.COLUMN_NAME_LIKES,
                TrendingQuestions.COLUMN_NAME_FOLLOWS,
                TrendingQuestions.COLUMN_NAME_ANSWERS
        };

        SQLiteDatabase db = trendingQuestionsDBHelper.getWritableDatabase();
        String query_text = TrendingQuestions._ID + "=" + next_position;

        Cursor cursor = db.query(TrendingQuestions.TABLE_NAME, allColumns, query_text, null, null, null, null);
        cursor.moveToFirst();

        String id = String.valueOf(cursor.getInt(0));
        String q_id = cursor.getString(1);
        String u_id = cursor.getString(2);
        String u_name = cursor.getString(3);
        String u_image = cursor.getString(4);
        String title = cursor.getString(5);
        String time = cursor.getString(6);
        String likes = cursor.getString(7);
        String follows = cursor.getString(8);
        String answers = cursor.getString(9);

        HashMap<String, String> question = new HashMap<>();

        question.put("id", id);
        question.put("q_id", q_id);
        question.put("u_id", u_id);
        question.put("u_name", u_name);
        question.put("u_image", u_image);
        question.put("title", title);
        question.put("time", time);
        question.put("likes", likes);
        question.put("follows", follows);
        question.put("answers", answers);
        cursor.close();

        return question;
    }












    public long insertInterestedQuestionsData(String id, String user_id, String user_name, String user_image,
                                            String title, String time, String likes,
                                            String follows, String answers) {

        SQLiteDatabase dbWriteable = interestedQuestionsDBHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InterestedQuestions.COLUMN_NAME_QUESTION_ID, id);
        values.put(InterestedQuestions.COLUMN_NAME_USER_ID, user_id);
        values.put(InterestedQuestions.COLUMN_NAME_USER_NAME, user_name);
        values.put(InterestedQuestions.COLUMN_NAME_USER_IMAGE, user_image);
        values.put(InterestedQuestions.COLUMN_NAME_TITLE, title);
        values.put(InterestedQuestions.COLUMN_NAME_TIMESTAMP, time);
        values.put(InterestedQuestions.COLUMN_NAME_LIKES, likes);
        values.put(InterestedQuestions.COLUMN_NAME_FOLLOWS, follows);
        values.put(InterestedQuestions.COLUMN_NAME_ANSWERS, answers);

        long newRowId = dbWriteable.insert(InterestedQuestions.TABLE_NAME, null, values);
        return newRowId;
    }

    public void invalidateInterestedQuestionsDatabase(){
        interestedQuestionsDBHelper.invalidData(interestedQuestionsDBHelper.getWritableDatabase());
    }

    public long getInterestedQuestionsCount() {
        SQLiteDatabase db = interestedQuestionsDBHelper.getReadableDatabase();
        long count = DatabaseUtils.queryNumEntries(db, InterestedQuestions.TABLE_NAME);
        return count;
    }

    public HashMap<String, String> getParticularInterestedQuestion(int position) {

        int next_position = position + 1;
        String[] allColumns = {
                InterestedQuestions._ID,
                InterestedQuestions.COLUMN_NAME_QUESTION_ID,
                InterestedQuestions.COLUMN_NAME_USER_ID,
                InterestedQuestions.COLUMN_NAME_USER_NAME,
                InterestedQuestions.COLUMN_NAME_USER_IMAGE,
                InterestedQuestions.COLUMN_NAME_TITLE,
                InterestedQuestions.COLUMN_NAME_TIMESTAMP,
                InterestedQuestions.COLUMN_NAME_LIKES,
                InterestedQuestions.COLUMN_NAME_FOLLOWS,
                InterestedQuestions.COLUMN_NAME_ANSWERS
        };

        SQLiteDatabase db = interestedQuestionsDBHelper.getWritableDatabase();
        String query_text = TrendingQuestions._ID + "=" + next_position;

        Cursor cursor = db.query(InterestedQuestions.TABLE_NAME, allColumns, query_text, null, null, null, null);
        cursor.moveToFirst();

        String id = String.valueOf(cursor.getInt(0));
        String q_id = cursor.getString(1);
        String u_id = cursor.getString(2);
        String u_name = cursor.getString(3);
        String u_image = cursor.getString(4);
        String title = cursor.getString(5);
        String time = cursor.getString(6);
        String likes = cursor.getString(7);
        String follows = cursor.getString(8);
        String answers = cursor.getString(9);

        HashMap<String, String> question = new HashMap<>();

        question.put("id", id);
        question.put("q_id", q_id);
        question.put("u_id", u_id);
        question.put("u_name", u_name);
        question.put("u_image", u_image);
        question.put("title", title);
        question.put("time", time);
        question.put("likes", likes);
        question.put("follows", follows);
        question.put("answers", answers);
        cursor.close();

        return question;
    }



    static class LatestQuestionsDBHelper extends SQLiteOpenHelper {
        // If you change the database schema, you must increment the database version.
        private static final int DATABASE_VERSION = 1;
        private static final String DATABASE_NAME = "jibedatabase";
        private static final String UID = "_id";
        private static final String TABLE_NAME = "LatestQuestions";

        private static final String TEXT_TYPE = " TEXT";
        private static final String COMMA_SEP = ",";
        private Context context;

        private static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + LatestQuestions.TABLE_NAME + "(" +
                        LatestQuestions._ID + " INTEGER PRIMARY KEY autoincrement, " +
                        LatestQuestions.COLUMN_NAME_QUESTION_ID + TEXT_TYPE + COMMA_SEP +
                        LatestQuestions.COLUMN_NAME_USER_ID + TEXT_TYPE + COMMA_SEP +
                        InterestedQuestions.COLUMN_NAME_USER_NAME + TEXT_TYPE + COMMA_SEP +
                        LatestQuestions.COLUMN_NAME_USER_IMAGE + TEXT_TYPE + COMMA_SEP +
                        LatestQuestions.COLUMN_NAME_TITLE + TEXT_TYPE + COMMA_SEP +
                        LatestQuestions.COLUMN_NAME_TIMESTAMP + TEXT_TYPE + COMMA_SEP +
                        LatestQuestions.COLUMN_NAME_LIKES + TEXT_TYPE + COMMA_SEP +
                        LatestQuestions.COLUMN_NAME_FOLLOWS + TEXT_TYPE + COMMA_SEP +
                        LatestQuestions.COLUMN_NAME_ANSWERS + TEXT_TYPE +
                        " );";

        private static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + LatestQuestions.TABLE_NAME;

        public LatestQuestionsDBHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
            this.context = context;
        }

        public void onCreate(SQLiteDatabase db) {
            try {
                db.execSQL(SQL_CREATE_ENTRIES);
            } catch (SQLException e) {
            }
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // This database is only a cache for online data, so its upgrade policy is
            // to simply to discard the data and start over
            try {
                db.execSQL(SQL_DELETE_ENTRIES);
                onCreate(db);
            } catch (SQLException e) {
            }
        }

        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            try {
                onUpgrade(db, oldVersion, newVersion);
            } catch (SQLException e) {
            }
        }

        public void invalidData(SQLiteDatabase db) {
            db.execSQL(SQL_DELETE_ENTRIES);
            db.execSQL(SQL_CREATE_ENTRIES);
        }
    }

    static class TrendingQuestionsDBHelper extends SQLiteOpenHelper {

        // If you change the database schema, you must increment the database version.
        private static final int DATABASE_VERSION = 1;
        private static final String DATABASE_NAME = "jibedatabase";
        private static final String TABLE_NAME = "TrendingQuestions";
        private static final String TEXT_TYPE = " TEXT";
        private static final String COMMA_SEP = ",";

        private Context context;

        private static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + TrendingQuestions.TABLE_NAME + "( " +
                        TrendingQuestions._ID + " INTEGER PRIMARY KEY, " +
                        TrendingQuestions.COLUMN_NAME_QUESTION_ID + TEXT_TYPE + COMMA_SEP +
                        TrendingQuestions.COLUMN_NAME_USER_ID + TEXT_TYPE + COMMA_SEP +
                        InterestedQuestions.COLUMN_NAME_USER_NAME + TEXT_TYPE + COMMA_SEP +
                        TrendingQuestions.COLUMN_NAME_USER_IMAGE + TEXT_TYPE + COMMA_SEP +
                        TrendingQuestions.COLUMN_NAME_TITLE + TEXT_TYPE + COMMA_SEP +
                        TrendingQuestions.COLUMN_NAME_TIMESTAMP + TEXT_TYPE + COMMA_SEP +
                        TrendingQuestions.COLUMN_NAME_LIKES + TEXT_TYPE + COMMA_SEP +
                        TrendingQuestions.COLUMN_NAME_FOLLOWS + TEXT_TYPE + COMMA_SEP +
                        TrendingQuestions.COLUMN_NAME_ANSWERS + TEXT_TYPE +
                        " );";
        private static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + TrendingQuestions.TABLE_NAME;

        public TrendingQuestionsDBHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
            this.context = context;
        }

        public void onCreate(SQLiteDatabase db) {
            try {
                db.execSQL(SQL_CREATE_ENTRIES);
            } catch (SQLException e) {
            }
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // This database is only a cache for online data, so its upgrade policy is
            // to simply to discard the data and start over
            try {
                db.execSQL(SQL_DELETE_ENTRIES);
                onCreate(db);
            } catch (SQLException e) {
            }
        }

        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            try {
                onUpgrade(db, oldVersion, newVersion);
            } catch (SQLException e) {
            }
        }

        public void invalidData(SQLiteDatabase db) {
            db.execSQL(SQL_DELETE_ENTRIES);
            db.execSQL(SQL_CREATE_ENTRIES);
        }
    }


    static class InterestedQuestionsDBHelper extends SQLiteOpenHelper {

        // If you change the database schema, you must increment the database version.
        private static final int DATABASE_VERSION = 1;
        private static final String DATABASE_NAME = "jibedatabase";
        private static final String TABLE_NAME = "InterestedQuestions";
        private static final String TEXT_TYPE = " TEXT";
        private static final String COMMA_SEP = ",";

        private Context context;

        private static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + InterestedQuestions.TABLE_NAME + "( " +
                        InterestedQuestions._ID + " INTEGER PRIMARY KEY, " +
                        InterestedQuestions.COLUMN_NAME_QUESTION_ID + TEXT_TYPE + COMMA_SEP +
                        InterestedQuestions.COLUMN_NAME_USER_ID + TEXT_TYPE + COMMA_SEP +
                        InterestedQuestions.COLUMN_NAME_USER_NAME + TEXT_TYPE + COMMA_SEP +
                        InterestedQuestions.COLUMN_NAME_USER_IMAGE + TEXT_TYPE + COMMA_SEP +
                        InterestedQuestions.COLUMN_NAME_TITLE + TEXT_TYPE + COMMA_SEP +
                        InterestedQuestions.COLUMN_NAME_TIMESTAMP + TEXT_TYPE + COMMA_SEP +
                        InterestedQuestions.COLUMN_NAME_LIKES + TEXT_TYPE + COMMA_SEP +
                        InterestedQuestions.COLUMN_NAME_FOLLOWS + TEXT_TYPE + COMMA_SEP +
                        InterestedQuestions.COLUMN_NAME_ANSWERS + TEXT_TYPE +
                        " );";
        private static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + InterestedQuestions.TABLE_NAME;

        public InterestedQuestionsDBHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
            this.context = context;
        }

        public void onCreate(SQLiteDatabase db) {
            try {
                db.execSQL(SQL_CREATE_ENTRIES);
            } catch (SQLException e) {
            }
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // This database is only a cache for online data, so its upgrade policy is
            // to simply to discard the data and start over
            try {
                db.execSQL(SQL_DELETE_ENTRIES);
                onCreate(db);
            } catch (SQLException e) {
            }
        }

        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            try {
                onUpgrade(db, oldVersion, newVersion);
            } catch (SQLException e) {
            }
        }

        public void invalidData(SQLiteDatabase db) {
            db.execSQL(SQL_DELETE_ENTRIES);
            db.execSQL(SQL_CREATE_ENTRIES);
        }
    }
}
