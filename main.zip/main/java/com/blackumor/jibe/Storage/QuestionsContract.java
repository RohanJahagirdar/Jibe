package com.blackumor.jibe.Storage;

import android.provider.BaseColumns;

/**
 * Created by Rohan on 11-08-2015.
 */
public final class QuestionsContract {

    public QuestionsContract() {}

    public static abstract class LatestQuestions implements BaseColumns {
        public static final String TABLE_NAME = "LatestQuestions";
        public static final String COLUMN_NAME_QUESTION_ID = "question_id";
        public static final String COLUMN_NAME_USER_ID = "user_id";
        public static final String COLUMN_NAME_USER_NAME = "user_name";
        public static final String COLUMN_NAME_USER_IMAGE = "user_image";
        public static final String COLUMN_NAME_TITLE = "title";
        public static final String COLUMN_NAME_TIMESTAMP = "timestamp";
        public static final String COLUMN_NAME_LIKES = "likes";
        public static final String COLUMN_NAME_FOLLOWS = "follows";
        public static final String COLUMN_NAME_ANSWERS = "answers";

    }

    public static abstract class TrendingQuestions implements BaseColumns {
        public static final String TABLE_NAME = "TrendingQuestions";
        public static final String COLUMN_NAME_QUESTION_ID = "question_id";
        public static final String COLUMN_NAME_USER_ID = "user_id";
        public static final String COLUMN_NAME_USER_NAME = "user_name";
        public static final String COLUMN_NAME_TITLE = "title";
        public static final String COLUMN_NAME_TIMESTAMP = "timestamp";
        public static final String COLUMN_NAME_LIKES = "likes";
        public static final String COLUMN_NAME_FOLLOWS = "follows";
        public static final String COLUMN_NAME_ANSWERS = "answers";
        public static final String COLUMN_NAME_USER_IMAGE = "user_image";
    }

    public static abstract class InterestedQuestions implements BaseColumns {
        public static final String TABLE_NAME = "InterestedQuestions";
        public static final String COLUMN_NAME_QUESTION_ID = "question_id";
        public static final String COLUMN_NAME_USER_ID = "user_id";
        public static final String COLUMN_NAME_USER_NAME = "user_name";
        public static final String COLUMN_NAME_TITLE = "title";
        public static final String COLUMN_NAME_TIMESTAMP = "timestamp";
        public static final String COLUMN_NAME_LIKES = "likes";
        public static final String COLUMN_NAME_FOLLOWS = "follows";
        public static final String COLUMN_NAME_ANSWERS = "answers";
        public static final String COLUMN_NAME_USER_IMAGE = "user_image";
    }
}
