package com.blackumor.jibe.Storage;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.blackumor.jibe.Storage.AnswersContract.Answers;

import java.util.HashMap;

/**
 * Created by Rohan on 11-08-2015.
 */

public class AnswersDBAdapter {

    AnswersDBHelper answersDBHelper;
    Context context;

    public void initialize(Context context) {
        answersDBHelper = new AnswersDBHelper(context);
    }

    public AnswersDBAdapter(Context context) {
        this.context = context;
    }




    public long insertAnswersData(String id, String question_id, String user_id, String user_image,
                                          String title, String time, String likes,
                                          String dislikes, String status) {
        SQLiteDatabase dbWriteable = answersDBHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Answers.COLUMN_NAME_ANSWER_ID, id);
        values.put(Answers.COLUMN_NAME_QUESTION_ID, question_id);
        values.put(Answers.COLUMN_NAME_USER_ID, user_id);
        values.put(Answers.COLUMN_NAME_USER_IMAGE, user_image);
        values.put(Answers.COLUMN_NAME_TITLE, title);
        values.put(Answers.COLUMN_NAME_TIMESTAMP, time);
        values.put(Answers.COLUMN_NAME_LIKES, likes);
        values.put(Answers.COLUMN_NAME_DISLIKES, dislikes);
        values.put(Answers.COLUMN_NAME_STATUS, status);

        long newRowId = dbWriteable.insert(Answers.TABLE_NAME, null, values);
        return newRowId;
    }

    public HashMap<String, String> getParticularAnswer(int position) {
        int next_position = position + 1;
        String[] allColumns = {
                Answers._ID,
                Answers.COLUMN_NAME_ANSWER_ID,
                Answers.COLUMN_NAME_QUESTION_ID,
                Answers.COLUMN_NAME_USER_ID,
                Answers.COLUMN_NAME_USER_IMAGE,
                Answers.COLUMN_NAME_TITLE,
                Answers.COLUMN_NAME_TIMESTAMP,
                Answers.COLUMN_NAME_LIKES,
                Answers.COLUMN_NAME_DISLIKES,
                Answers.COLUMN_NAME_STATUS
        };

        SQLiteDatabase db = answersDBHelper.getWritableDatabase();
        String query_text = Answers._ID + "=" + next_position;

        Cursor cursor = db.query(Answers.TABLE_NAME, allColumns, query_text, null, null, null, null);
        cursor.moveToFirst();

        String id = String.valueOf(cursor.getInt(0));
        String a_id = cursor.getString(1);
        String q_id = cursor.getString(2);
        String u_id = cursor.getString(3);
        String u_image = cursor.getString(4);
        String title = cursor.getString(5);
        String time = cursor.getString(6);
        String likes = cursor.getString(7);
        String follows = cursor.getString(8);
        String status = cursor.getString(9);


        HashMap<String, String> answer = new HashMap<>();

        answer.put("id", id);
        answer.put("a_id", a_id);
        answer.put("q_id", q_id);
        answer.put("u_id", u_id);
        answer.put("u_image", u_image);
        answer.put("title", title);
        answer.put("time", time);
        answer.put("likes", likes);
        answer.put("dislikes", follows);
        answer.put("status", status);
        cursor.close();
        return answer;
    }


    public  String getParticularAnswerId(int position) {
        String[] allColumns = {
                Answers.COLUMN_NAME_ANSWER_ID
        };

        SQLiteDatabase db = answersDBHelper.getWritableDatabase();
        String query_text = Answers._ID + "=" + position;

        System.out.println(query_text);

        Cursor cursor = db.query(Answers.TABLE_NAME, allColumns, query_text, null, null, null, null);
        cursor.moveToFirst();

        String id = String.valueOf(cursor.getInt(0));
        return id;
    }



    public String getLastAnswerId(int position) {
        int next_position = position + 1;
        String[] allColumns = { Answers.COLUMN_NAME_ANSWER_ID };
        SQLiteDatabase db = answersDBHelper.getWritableDatabase();
        String query_text = Answers._ID + "=" + next_position;
        Cursor cursor = db.query(Answers.TABLE_NAME, allColumns, query_text, null, null, null, null);
        cursor.moveToFirst();
        String a_id = cursor.getString(0);
        return a_id;
    }


    public void updateAnswerLike(int answer_id) {
        SQLiteDatabase db = answersDBHelper.getWritableDatabase();
        ContentValues args = new ContentValues();
        args.put(Answers.COLUMN_NAME_STATUS, "1");
         db.update(Answers.TABLE_NAME, args, Answers.COLUMN_NAME_ANSWER_ID + "=" + answer_id, null);
    }

    public void updateAnswerUnDisLike(int answer_id) {
        SQLiteDatabase db = answersDBHelper.getWritableDatabase();
        ContentValues args = new ContentValues();
        args.put(Answers.COLUMN_NAME_STATUS, "0");
        db.update(Answers.TABLE_NAME, args, Answers.COLUMN_NAME_ANSWER_ID + "=" + answer_id, null);
    }

    public void updateAnswerDisLike(int answer_id) {
        SQLiteDatabase db = answersDBHelper.getWritableDatabase();
        ContentValues args = new ContentValues();
        args.put(Answers.COLUMN_NAME_STATUS, "-1");
        db.update(Answers.TABLE_NAME, args, Answers.COLUMN_NAME_ANSWER_ID + "=" + answer_id, null);
    }

    public void updateAnswerUnLike(int answer_id) {
        SQLiteDatabase db = answersDBHelper.getWritableDatabase();
        ContentValues args = new ContentValues();
        args.put(Answers.COLUMN_NAME_STATUS, "0");
        db.update(Answers.TABLE_NAME, args, Answers.COLUMN_NAME_ANSWER_ID + "=" + answer_id, null);
    }




    public void invalidateAnswersDatabase(){
        answersDBHelper.invalidData(answersDBHelper.getWritableDatabase());
    }


    public long getAnswersCount() {
        SQLiteDatabase db = answersDBHelper.getReadableDatabase();
        long count = DatabaseUtils.queryNumEntries(db, Answers.TABLE_NAME);
        count = count+1;
        return count;
    }


    public class AnswersDBHelper extends SQLiteOpenHelper {

        // If you change the database schema, you must increment the database version.
        public static final int DATABASE_VERSION = 1;
        public static final String DATABASE_NAME = "Answers.db";

        private static final String TEXT_TYPE = " TEXT";
        private static final String COMMA_SEP = ",";
        private static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + Answers.TABLE_NAME + " (" +
                        Answers._ID + " INTEGER PRIMARY KEY," +
                        Answers.COLUMN_NAME_ANSWER_ID + TEXT_TYPE + COMMA_SEP +
                        Answers.COLUMN_NAME_QUESTION_ID + TEXT_TYPE + COMMA_SEP +
                        Answers.COLUMN_NAME_USER_ID + TEXT_TYPE + COMMA_SEP +
                        Answers.COLUMN_NAME_USER_IMAGE + TEXT_TYPE + COMMA_SEP +
                        Answers.COLUMN_NAME_TITLE + TEXT_TYPE + COMMA_SEP +
                        Answers.COLUMN_NAME_TIMESTAMP + TEXT_TYPE + COMMA_SEP +
                        Answers.COLUMN_NAME_LIKES + TEXT_TYPE + COMMA_SEP +
                        Answers.COLUMN_NAME_DISLIKES + TEXT_TYPE + COMMA_SEP +
                        Answers.COLUMN_NAME_STATUS + TEXT_TYPE +
                        " );";

        private static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS " + Answers.TABLE_NAME;

        public AnswersDBHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        public void onCreate(SQLiteDatabase db) {
            db.execSQL(SQL_CREATE_ENTRIES);
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // This database is only a cache for online data, so its upgrade policy is
            // to simply to discard the data and start over
            db.execSQL(SQL_DELETE_ENTRIES);
            onCreate(db);
        }

        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            onUpgrade(db, oldVersion, newVersion);
        }

        public void invalidData(SQLiteDatabase db) {
            db.execSQL(SQL_DELETE_ENTRIES);
            db.execSQL(SQL_CREATE_ENTRIES);
        }
    }
}