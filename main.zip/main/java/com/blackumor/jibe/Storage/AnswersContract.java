package com.blackumor.jibe.Storage;

import android.provider.BaseColumns;

/**
 * Created by Rohan on 11-08-2015.
 */
public final class AnswersContract {

    public AnswersContract() {}

    public static abstract class Answers implements BaseColumns {
        public static final String TABLE_NAME = "Answers";
        public static final String COLUMN_NAME_ANSWER_ID = "id";
        public static final String COLUMN_NAME_QUESTION_ID = "question_id";
        public static final String COLUMN_NAME_USER_ID = "user_id";
        public static final String COLUMN_NAME_USER_IMAGE = "user_image";
        public static final String COLUMN_NAME_TITLE = "title";
        public static final String COLUMN_NAME_TIMESTAMP = "timestamp";
        public static final String COLUMN_NAME_LIKES = "likes";
        public static final String COLUMN_NAME_DISLIKES = "dislikes";
        public static final String COLUMN_NAME_STATUS = "status";

    }
}
