package com.blackumor.jibe.Storage;

/**
 * Created by Rohan on 18-10-2015.
 */
public interface FetchCompleteListener {
    void fetchComplete();
}
