package com.blackumor.jibe.Dashboard;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.blackumor.jibe.Networking.OkHttpRequest;
import com.blackumor.jibe.Onboarding.JibeApplication;
import com.blackumor.jibe.Processing.QuestionsResponse;
import com.blackumor.jibe.Storage.FetchCompleteListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import jibe.blackumor.com.jibe.R;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Response;

/**
 * Created by Rohan on 10-10-2015.
 */
public class InterestedFragment extends Fragment implements FetchCompleteListener{

    InterestedContentAdapter adapter;

    RecyclerView list = null;
    LinearLayoutManager llManager;

    OkHttpClient client = new OkHttpClient();
    OkHttpRequest request;
    private SharedPreferences prefs;
    private String PREFS_NAME = "JibePrefsFile";
    JibeApplication jibeApplication;

    public  static InterestedFragment getInstance() {
        InterestedFragment trendingFragment = new InterestedFragment();
        return  trendingFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_latest, container, false);
        list = (RecyclerView)view.findViewById(R.id.recyclerView);
        list.setHasFixedSize(true);
        llManager = new LinearLayoutManager(getActivity());
        list.setLayoutManager(llManager);
        adapter = new InterestedContentAdapter(getActivity());
        list.setAdapter(adapter);
        jibeApplication = new JibeApplication();
        return view;
    }

    public void fetchQuestions() {
        String url =  getResources().getString(R.string.base_url) + "/questions/interested/index.php";
        System.out.println(url);
        request = new OkHttpRequest(client);
        request.GET(url, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println(e);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getActivity(), "Network issues. Interested.", Toast.LENGTH_SHORT).show();
                    }
                });

                //Intent intent = new Intent(.this, CategoriesListActivity.class);
                //startActivity(intent);

            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                try {
                    String responseStr = response.body().string();
                    final JSONObject json = new JSONObject(responseStr);
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                int valid = json.getInt("valid");
                                if (valid == 1) {
                                    new QuestionsResponse(getActivity()).parseInterested(InterestedFragment.this, json);
                                } else {
                                    //    prefs.edit().remove("email").remove("pass").
                                    //            remove("session_id").apply();
                                    //                                Intent intent = new Intent(LoginActivity.this, CategoriesListActivity.class);
                                    //                                startActivity(intent);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void fetchComplete() {
        adapter.notifyDataSetChanged();
        // new QuestionsResponse(getActivity()).getAllLatestQuestionsData();

    }
}
