package com.blackumor.jibe.Dashboard;

import android.support.v4.app.Fragment;

/**
 * Created by Rohan on 10-10-2015.
 */
public class UsersFragment extends Fragment {

    public  static UsersFragment getInstance() {
        UsersFragment usersFragment = new UsersFragment();
        return  usersFragment;
    }
}
