package com.blackumor.jibe.Dashboard;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.blackumor.jibe.Dashboard.Answers.AnswersActivity;
import com.blackumor.jibe.Onboarding.JibeApplication;
import com.blackumor.jibe.Storage.QuestionsDBAdapter;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import jibe.blackumor.com.jibe.R;

/**
 * Created by Rohan on 11-04-2015.
 */
public class TrendingContentAdapter extends RecyclerView.Adapter<TrendingContentAdapter.ViewHolder>{

    static Context context;
    private Resources res;
    private LayoutInflater inflater = null;
    SQLiteDatabase dbReadable;
    QuestionsDBAdapter questionsDBAdapter;
    JibeApplication jibeApplication;

    public TrendingContentAdapter(Context c) {
        context = c;
        res = c.getResources();
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        questionsDBAdapter = ((JibeApplication)context.getApplicationContext()).getQuestionsDBAdapter();
        jibeApplication = (JibeApplication)context.getApplicationContext();
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int position) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.question_cardview, parent, false);
        ViewHolder viewHolder = new ViewHolder(v, position);


        return viewHolder;
    }

    public static interface ViewHolderClicks {

    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int position) {
        //   viewHolder.rewardImage.
        //profile_image =
        HashMap<String, String> question = (HashMap<String, String>)getQuestion(position);
        String id = question.get("id");
        String q_id = question.get("q_id");
        String u_id = question.get("u_id");
        String u_name = question.get("u_name");
        String u_image = question.get("u_image");
        String title = question.get("title");
        String timestamp = question.get("time");
        String likes = question.get("likes");
        String follows = question.get("follows");
        String answers = question.get("answers");

        viewHolder.creator.setText("-" +  u_name);
        viewHolder.creator_image = u_image;
        viewHolder.question.setText("Q)  " +title);
        viewHolder.likes.setText(likes);
        viewHolder.answers.setText(answers);
        viewHolder.time.setText(getTimeDifference(timestamp));
        jibeApplication.setCreatorImage(Integer.parseInt(u_image), viewHolder.profile_image);
    }

    private String getTimeDifference(String timestamp) {
        long current = System.currentTimeMillis()/1000;
        String difference = "";
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = format.parse(timestamp);
            difference = String.valueOf(DateUtils.getRelativeTimeSpanString (date.getTime(), System.currentTimeMillis(), DateUtils.SECOND_IN_MILLIS));
        } catch ( ParseException e) {

        }
        return difference;
    }

    /*
    private String getTimeDifference(String timestamp) {
        long current = System.currentTimeMillis()/1000;


        String difference = (String)DateUtils.getRelativeTimeSpanString (Long.valueOf(timestamp), System.currentTimeMillis(), DateUtils.SECOND_IN_MILLIS);
        return difference;
    }

    */

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public int getItemCount() {
        int count;
        count = (int) ((JibeApplication)context.getApplicationContext()).getQuestionsDBAdapter().getTrendingQuestionsCount();
        return count;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public int position = 0;

        public View view;
        CardView questions_cardview;
        TextView question, creator, likes, answers, time;
        ImageView profile_image;
        String creator_image;

        public ViewHolder(View v, int position) {
            super(v);
            view = v;
            this.position = position;
            profile_image = (ImageView) v.findViewById(R.id.question_profile_image);
            question = (TextView) v.findViewById(R.id.question);
            creator = (TextView)v.findViewById(R.id.question_creator);
            likes = (TextView) v.findViewById(R.id.likes_count);
            answers = (TextView) v.findViewById(R.id.answers_count);
            time = (TextView) v.findViewById(R.id.time);
        }

        @Override
        public void onClick(View v) {
            Intent i = new Intent(context, AnswersActivity.class);
            i.putExtra("creator", creator.getText().toString());
            i.putExtra("creator_image", creator_image);
            i.putExtra("likes", likes.getText().toString());
            i.putExtra("title", question.getText().toString());
            i.putExtra("time", time.getText().toString());
            i.putExtra("answers", answers.getText().toString());
            context.startActivity(i);
        }
    }

    public HashMap getQuestion(int position) {
        return questionsDBAdapter.getParticularTrendingQuestion(position);
    }




}
