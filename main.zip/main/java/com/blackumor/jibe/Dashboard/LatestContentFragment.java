package com.blackumor.jibe.Dashboard;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;


import com.blackumor.jibe.Networking.OkHttpRequest;
import com.blackumor.jibe.Onboarding.JibeApplication;
import com.blackumor.jibe.Processing.QuestionsResponse;
import com.blackumor.jibe.Storage.FetchCompleteListener;
import com.blackumor.jibe.Storage.QuestionsContract.LatestQuestions;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;

import jibe.blackumor.com.jibe.R;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Response;

/**
 * Created by Rohan on 10-10-2015.
 */
public class LatestContentFragment extends Fragment implements FetchCompleteListener{
    LatestContentAdapter adapter;

    RecyclerView list = null;
    LinearLayoutManager llManager;

    OkHttpClient client = new OkHttpClient();
    OkHttpRequest request;
    private SharedPreferences prefs;
    private String PREFS_NAME = "JibePrefsFile";
    SwipeRefreshLayout swipeRefreshLayout;

    JibeApplication jibeApplication;

    public  static LatestContentFragment getInstance() {
        LatestContentFragment latestContentFragment = new LatestContentFragment();
        return  latestContentFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fetchQuestions();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        System.out.println("latest content act oncreate.");
        View view = inflater.inflate(R.layout.fragment_latest, container, false);
        list = (RecyclerView)view.findViewById(R.id.recyclerView);
        swipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.activity_main_swipe_refresh_layout);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent, R.color.ColorPrimary, R.color.w1ColorPrimary);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                System.out.println("Swipe Refresh Layout Called. Need to refresh the list and populate with new questions.");
                setTestRefreshTime();

            }
        });
        list.setHasFixedSize(true);
        llManager = new LinearLayoutManager(getActivity());
        list.setLayoutManager(llManager);
        adapter = new LatestContentAdapter(getActivity());
        list.setAdapter(adapter);
        jibeApplication = new JibeApplication();
        return view;
    }

    public void fetchQuestions() {
        String url = getResources().getString(R.string.base_url) + "/questions/latest/index.php";
        System.out.println(url);
        request = new OkHttpRequest(client);
        request.GET(url, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                try {
                String responseStr = "";
                final JSONObject json = new JSONObject(responseStr);
                System.out.println(e);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getActivity(), "Network issues. Latest.", Toast.LENGTH_SHORT).show();
                        ((DashboardActivity)getActivity()).fetchTrending();
                        //new QuestionsResponse(getActivity()).parseLatest(LatestContentFragment.this, json);

                    }
                });

                //Intent intent = new Intent(.this, CategoriesListActivity.class);
                //startActivity(intent);
                } catch (JSONException je) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                try {
                    String responseStr = response.body().string();
                    final JSONObject json = new JSONObject(responseStr);
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                int valid = json.getInt("valid");
                                if (valid == 1) {
                                    new QuestionsResponse(getActivity()).parseLatest(LatestContentFragment.this, json);
                                } else {
                                    //    prefs.edit().remove("email").remove("pass").
                                    //            remove("session_id").apply();
                                    //                                Intent intent = new Intent(LoginActivity.this, CategoriesListActivity.class);
                                    //                                startActivity(intent);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void fetchComplete() {
        adapter.notifyDataSetChanged();
        ((DashboardActivity)getActivity()).fetchTrending();
    }

    public void setTestRefreshTime() {
        int interval = 3000;
        Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                swipeRefreshLayout.setRefreshing(false);
            }
        };
        handler.postAtTime(runnable, System.currentTimeMillis() + interval);
        handler.postDelayed(runnable, interval);
    }

    public void fetchNewQuestions(int position) {
        String url = getResources().getString(R.string.base_url) + "/questions/latest/refetch_index.php?position=" + position ;
        System.out.println(url);
        request = new OkHttpRequest(client);
        request.GET(url, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                try {
                    String responseStr = "";
                    final JSONObject json = new JSONObject(responseStr);
                    System.out.println(e);
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getActivity(), "Network issues. Latest.", Toast.LENGTH_SHORT).show();
                            ((DashboardActivity)getActivity()).fetchTrending();
                            //new QuestionsResponse(getActivity()).parseLatest(LatestContentFragment.this, json);

                        }
                    });

                    //Intent intent = new Intent(.this, CategoriesListActivity.class);
                    //startActivity(intent);
                } catch (JSONException je) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                try {
                    String responseStr = response.body().string();
                    final JSONObject json = new JSONObject(responseStr);
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                int valid = json.getInt("valid");
                                if (valid == 1) {
                           //         new QuestionsResponse(getActivity()).parseLatest(LatestContentFragment.this, json);
                                } else {
                                    //    prefs.edit().remove("email").remove("pass").
                                    //            remove("session_id").apply();
                                    //                                Intent intent = new Intent(LoginActivity.this, CategoriesListActivity.class);
                                    //                                startActivity(intent);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

}
