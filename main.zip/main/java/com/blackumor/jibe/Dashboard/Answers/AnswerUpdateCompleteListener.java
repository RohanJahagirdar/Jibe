package com.blackumor.jibe.Dashboard.Answers;

/**
 * Created by Rohan on 18-10-2015.
 */
public interface AnswerUpdateCompleteListener {
    void updateAnswerComplete();
    void updateAnswerDislikeComplete();
    void updateAnswerLikeComplete();
    void updateAnswerUnLikeComplete();
    void updateAnswerUnDisLikeComplete();

}
