package com.blackumor.jibe.Dashboard.Answers;

import android.content.Context;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.widget.TextViewCompat;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.blackumor.jibe.Onboarding.JibeApplication;
import com.blackumor.jibe.Storage.AnswersDBAdapter;

import java.util.HashMap;
import jibe.blackumor.com.jibe.R;

/**
 * Created by Rohan on 11-04-2015.
 */

public class AnswersAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_QUESTION = 0;
    private static final int TYPE_ANSWER = 1;

    Context context;
    private Resources res;
    private LayoutInflater inflater = null;
    SQLiteDatabase dbReadable;
    AnswersDBAdapter answersDBAdapter;
    JibeApplication jibeApplication;
    HashMap<String, String> question_map;
    String question_id, question_creator, question_u_image, question_title, question_time, question_likes, question_answers;

    Drawable  dislikes_image_active, dislikes_image_inactive;
    Drawable likes_image_active, likes_image_inactive;


    AnswerUpdateCompleteListener answerUpdateCompleteListener;


    public AnswersAdapter(Context c, HashMap<String,String> question) {
        context = c;
        question_map = question;
        res = c.getResources();
        likes_image_active = res.getDrawable(R.drawable.ic_done_all_black);
        dislikes_image_active = res.getDrawable(R.drawable.ic_done_all_black);

        likes_image_inactive = res.getDrawable(R.drawable.ic_thumb_up_black);
        dislikes_image_inactive = res.getDrawable(R.drawable.ic_thumb_down_black);

        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        answersDBAdapter = ((JibeApplication)context.getApplicationContext()).getAnswersDBAdapter();
        jibeApplication = (JibeApplication)context.getApplicationContext();

        question_id = question_map.get("question_id");
        question_creator = question_map.get("u_id");
        question_u_image = question_map.get("u_image");
        question_title = question_map.get("title");
        question_time = question_map.get("time");
        question_likes = question_map.get("likes");
        question_answers = question_map.get("answers");
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if(viewType == TYPE_QUESTION) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.question_cardview, parent, false);
            return  new Question(v);
        }
        else if(viewType == TYPE_ANSWER) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.answer_cardview, parent, false);
            return new Answer(v);
        }
        throw new RuntimeException("there is no type that matches the type " + viewType + " + make sure your using types correctly");
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if(holder instanceof Question) {
            Question question = (Question)holder;
            question.question_creator.setText(question_creator);
            question.question_likes.setText(question_likes);
            question.question_title.setText(question_title);
            question.question_time.setText(question_time);
            question.question_answers.setText(question_answers);
            jibeApplication.setCreatorImage(Integer.parseInt(question_u_image), question.question_creator_image);

        }
        else if(holder instanceof Answer) {
            Answer answer = (Answer)holder;
            HashMap<String, String> answer_map = (HashMap<String, String>) getAnswer(position);
            String id = answer_map.get("id");
            String answer_id = answer_map.get("answer_id");
            String q_id = answer_map.get("q_id");
            String u_id = answer_map.get("u_id");
            String u_image = answer_map.get("u_image");
            String title = answer_map.get("title");
            String timestamp = answer_map.get("time");
            String likes = answer_map.get("likes");
            String dislikes = answer_map.get("dislikes");
            String status = answer_map.get("status");

            answer.answer_creator.setText("-" + u_id);
            answer.answer_title.setText("A)  " + title);
            answer.answer_likes_active.setText(likes);
            answer.answer_likes_inactive.setText(likes);

            answer.answer_dislikes_active.setText(dislikes);
            answer.answer_dislikes_inactive.setText(dislikes);

            if(position > 0) {
                if (status.equals("1")) {
                    answer.answer_likes_active.setVisibility(View.VISIBLE);
                    answer.answer_likes_inactive.setVisibility(View.GONE);

                    answer.answer_dislikes_active.setVisibility(View.GONE);
                    answer.answer_dislikes_inactive.setVisibility(View.VISIBLE);
                    System.out.println("Like: " + position);

                } else if (status.equals("-1")) {
                    answer.answer_dislikes_active.setVisibility(View.VISIBLE);
                    answer.answer_dislikes_inactive.setVisibility(View.GONE);

                    answer.answer_likes_active.setVisibility(View.GONE);
                    answer.answer_likes_inactive.setVisibility(View.VISIBLE);
                    System.out.println("Dislike: " + position);
                } else {

                    answer.answer_likes_active.setVisibility(View.GONE);
                    answer.answer_dislikes_active.setVisibility(View.GONE);

                    answer.answer_dislikes_inactive.setVisibility(View.VISIBLE);
                    answer.answer_likes_inactive.setVisibility(View.VISIBLE);
                    System.out.println("None: " + position);
                }
            }
            answer.answer_time.setText(getTimeDifference(timestamp));
            jibeApplication.setCreatorImage(Integer.parseInt(u_image), answer.answer_creator_image);
        }

    }

    @Override
    public int getItemViewType(int position) {
        if(isPositionHeader(position))
            return TYPE_QUESTION;
        return TYPE_ANSWER;
    }

    private boolean isPositionHeader(int position) {
        return position == 0;
    }

    @Override
    public int getItemCount() {
        int count;
        count = (int) ((JibeApplication)context.getApplicationContext()).getAnswersDBAdapter().getAnswersCount();
        return count;
    }

    private String getTimeDifference(String timestamp) {
        long current = System.currentTimeMillis()/1000;
    //    String difference = (String)DateUtils.getRelativeTimeSpanString(Long.parseLong(timestamp)*1000);
        return timestamp;
    }

    public HashMap getAnswer(int position) {
        return answersDBAdapter.getParticularAnswer(position -1);
    }

    public String getAnswerId(int position) {
        return answersDBAdapter.getParticularAnswer(position -1).get("a_id");
    }



    class Question extends RecyclerView.ViewHolder{
        TextView question_title, question_creator, question_time, question_likes, question_answers;
        ImageView question_creator_image;

        public Question(View header) {
            super(header);
            question_creator = (TextView) header.findViewById(R.id.question_creator);
            question_creator_image = (ImageView) header.findViewById(R.id.question_profile_image);
            question_time = (TextView) header.findViewById(R.id.time);
            question_title = (TextView) header.findViewById(R.id.question);
            question_likes = (TextView) header.findViewById(R.id.likes_count);
            question_answers = (TextView) header.findViewById(R.id.answers_count);
        }
    }

    class Answer extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView answer_title, answer_creator, answer_time, answer_dislikes_active, answer_dislikes_inactive,
            answer_likes_active, answer_likes_inactive;
        ImageView answer_creator_image;

        public Answer(View view) {
            super(view);
            answer_creator_image = (ImageView) view.findViewById(R.id.answer_profile_image);
            answer_title = (TextView) view.findViewById(R.id.answer);
            answer_creator = (TextView) view.findViewById(R.id.answer_creator);
            answer_likes_active = (TextView) view.findViewById(R.id.likes_count_active);
            answer_likes_inactive = (TextView) view.findViewById(R.id.likes_count_inactive);
            answer_time = (TextView) view.findViewById(R.id.time);
            answer_dislikes_active = (TextView) view.findViewById(R.id.dislikes_count_active);
            answer_dislikes_inactive = (TextView) view.findViewById(R.id.dislikes_count_inactive);

            answer_likes_active.setOnClickListener(this);
            answer_likes_inactive.setOnClickListener(this);

            answer_dislikes_active.setOnClickListener(this);
            answer_dislikes_inactive.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {
            int position = this.getAdapterPosition();
           // answerUpdateCompleteListener

        /*
            1.neutral to like
            2.like to neutral

            3.dislike to neutral
            4.neutral to dislike
        */

            if (v.getId() == answer_likes_inactive.getId()) {

                System.out.println("Like Answer position: " + getAnswerId(position));
                System.out.println("For Question: " + question_id);

                String action;
                if(answer_dislikes_active.getVisibility() == View.VISIBLE) {
                    //previously unliked, disliked video:::: to liked, undisliked  ->
                    //1.dislike to like
                    action = "6";
                } else {
                    //previously unliked, undisliked video:::: to liked, undisliked
                    //1.neutral to like
                    action = "1";
                }


                ((AnswersActivity)context).updateAnswerLike(getAnswerId(position), action);
                ((JibeApplication)context.getApplicationContext()).getAnswersDBAdapter().
                        updateAnswerLike(Integer.valueOf(getAnswerId(position)));

                answer_likes_active.setVisibility(View.VISIBLE);
                answer_likes_inactive.setVisibility(View.GONE);

                answer_dislikes_active.setVisibility(View.GONE);
                answer_dislikes_inactive.setVisibility(View.VISIBLE);


            } else if (v.getId() == answer_likes_active.getId()) {

                System.out.println("UnLike Answer position: " + getAnswerId(position));
                System.out.println("For Question: " + question_id);

                String action;
                if(answer_dislikes_active.getVisibility() == View.VISIBLE) {
                    //previously liked, disliked video:::: to unliked, undisliked  ->
                    // 3.dislike to neutral
                    action = "3";
                } else {
                    //previously liked, undisliked video:::: to unliked, undisliked
                    // 2.like to neutral
                    action = "2";
                }

                ((AnswersActivity)context).updateAnswerLike(getAnswerId(position), action);
                ((JibeApplication)context.getApplicationContext()).getAnswersDBAdapter().
                        updateAnswerUnLike(Integer.valueOf(getAnswerId(position)));

                answer_likes_active.setVisibility(View.GONE);
                answer_likes_inactive.setVisibility(View.VISIBLE);

                answer_dislikes_active.setVisibility(View.GONE);
                answer_dislikes_inactive.setVisibility(View.VISIBLE);


            } else if (v.getId() == answer_dislikes_active.getId()){
                //3.dislike to neutral
                System.out.println("UnDislike Answer position: " + getAnswerId(position));
                System.out.println("For Question: " + question_id);

                String action = "0";
                if(answer_likes_active.getVisibility() == View.VISIBLE) {
                    //previously liked, disliked video:::: to unliked, undisliked-> neutral
                    action = "-1";
                } else {
                    //previously unliked, disliked video:::: to unliked, undisliked
                    // 2.dislike to neutral
                    action = "3";
                }
                ((AnswersActivity)context).updateAnswerDislike(getAnswerId(position), action);
                ((JibeApplication)context.getApplicationContext()).getAnswersDBAdapter().
                        updateAnswerUnDisLike(Integer.valueOf(getAnswerId(position)));

                answer_likes_active.setVisibility(View.GONE);
                answer_likes_inactive.setVisibility(View.VISIBLE);

                answer_dislikes_active.setVisibility(View.GONE);
                answer_dislikes_inactive.setVisibility(View.VISIBLE);


            } else if (v.getId() == answer_dislikes_inactive.getId()){
                //4.neutral to dislike
                System.out.println("Dislike Answer position: " + getAnswerId(position));
                System.out.println("For Question: " + question_id);

                String action = "0";
                if(answer_likes_active.getVisibility() == View.VISIBLE) {
                    //previously liked, undisliked video:::: to unliked, disliked-> neutral
                    action = "5";
                } else {
                    //previously unliked, disliked video:::: to unliked, disliked
                    // 2.neutral to disliked
                    action = "4";
                }


                ((AnswersActivity)context).updateAnswerDislike(getAnswerId(position), action);
                ((JibeApplication)context.getApplicationContext()).getAnswersDBAdapter().
                        updateAnswerDisLike(Integer.valueOf(getAnswerId(position)));

                answer_likes_active.setVisibility(View.GONE);
                answer_likes_inactive.setVisibility(View.VISIBLE);

                answer_dislikes_active.setVisibility(View.VISIBLE);
                answer_dislikes_inactive.setVisibility(View.GONE);
            }
        }
    }
}