package com.blackumor.jibe.Dashboard.Answers;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.blackumor.jibe.Dashboard.LatestContentAdapter;
import com.blackumor.jibe.Networking.OkHttpRequest;
import com.blackumor.jibe.Onboarding.JibeApplication;
import com.blackumor.jibe.Processing.AnswersResponse;
import com.blackumor.jibe.Processing.QuestionsResponse;
import com.blackumor.jibe.Storage.AnswersDBAdapter;
import com.blackumor.jibe.Storage.FetchCompleteListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;

import jibe.blackumor.com.jibe.R;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Response;

public class AnswersActivity extends AppCompatActivity implements FetchCompleteListener{

    OkHttpClient client = new OkHttpClient();
    OkHttpRequest request;

    RecyclerView list = null;
    LinearLayoutManager llManager;
    AnswersAdapter adapter;
    JibeApplication jibeApplication;
    String question_id;
    TextView no_answers;

    SharedPreferences prefs;
    String PREFS_NAME = "JibeTheApp";

    FloatingActionButton create_answer_fab;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answers);
    //    answer = (TextView) findViewById(R.id.answer);
        System.out.println("ans act oncreate.");
        Bundle extras = getIntent().getExtras();

        prefs = getSharedPreferences(PREFS_NAME, 0);

        final String q_id = extras.getString("question_id");

        String creator = extras.getString("creator");
        String creator_image = extras.getString("creator_image");
        String likes = extras.getString("likes");
        String title = extras.getString("title");
        String time = extras.getString("times");
        String answers = extras.getString("answers");

        this.question_id = q_id;

        HashMap<String,String> question = new HashMap();
        question.put("question_id",question_id);
        question.put("u_id",creator);
        question.put("u_image",creator_image);
        question.put("title",title);
        question.put("time",time);
        question.put("likes",likes);
        question.put("answers",answers);

        list = (RecyclerView)findViewById(R.id.recyclerView);
        list.setHasFixedSize(true);
        llManager = new LinearLayoutManager(this);
        list.setLayoutManager(llManager);
        adapter = new AnswersAdapter(this, question);
        list.setAdapter(adapter);
        jibeApplication = new JibeApplication();

        no_answers = (TextView) findViewById(R.id.no_answers_text);
        no_answers.setVisibility(View.INVISIBLE);

        create_answer_fab = (FloatingActionButton) findViewById(R.id.fab);
        create_answer_fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(AnswersActivity.this);
                LayoutInflater inflater = getLayoutInflater();
                final View create_question_dialog = inflater.inflate(R.layout.fragment_create_answer, null);
                final EditText answer = (EditText) create_question_dialog.findViewById(R.id.answer);

                builder.setView(create_question_dialog);
                builder.setPositiveButton("Create", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        //Toast.makeText(DashboardActivity.this, "Question created!"+ question.getText().toString().trim(), Toast.LENGTH_SHORT).show();
                        publishAnswer("", q_id, answer.getText().toString().trim());
                    }
                })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                            }
                        });
                builder.create().show();
            }
        });

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getAnswers();
    }


    public void getAnswers() {
        String url = getResources().getString(R.string.base_url) + "/answers/index.php?question_id=" +question_id;
               //+ "&last_id =" + ((JibeApplication)getApplicationContext()).getAnswersDBAdapter().getLastAnswerId(getCount());
        System.out.println(url);
        request = new OkHttpRequest(client);
        request.GET(url, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println(e);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(AnswersActivity.this, "Network issues. Answers.", Toast.LENGTH_SHORT).show();
                    }
                });

                //Intent intent = new Intent(.this, CategoriesListActivity.class);
                //startActivity(intent);

            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                try {
                    final String responseStr = response.body().string();
                    final JSONObject json = new JSONObject(responseStr);
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                int valid = json.getInt("valid");
                                JSONArray order = json.getJSONArray("order");
                                if (valid == 1) {
                                    if (order.length() == 0) {
                                        System.out.println("order length is 0.");
                                        fetchComplete();
                                    } else {
                                        System.out.println("order length is greater than 0.");
                                        new AnswersResponse(AnswersActivity.this).parseAnswers(AnswersActivity.this, json);
                                    }

                                } else {

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    @Override
    public void fetchComplete() {
        adapter.notifyDataSetChanged();
        getCount();
    }

    @Override
    public void onBackPressed() {
        AnswersDBAdapter answersDBAdapter = new AnswersDBAdapter(this);
        answersDBAdapter.initialize(this);
        answersDBAdapter.invalidateAnswersDatabase();
        super.onBackPressed();
    }

    private int getCount() {
        int count = (int) ((JibeApplication)getApplicationContext()).getAnswersDBAdapter().getAnswersCount();
        if(count ==1){
            System.out.println("No Answers");
            no_answers.setVisibility(View.VISIBLE);
        } else {
            System.out.println("Answers Present");
            no_answers.setVisibility(View.INVISIBLE);
        }

        return count;
    }


    public void publishAnswer(String session_id, String question_id, String answer) {
        String url = getResources().getString(R.string.base_url) + "/answers/create.php";

        HashMap<String, String> params = new HashMap<>();
        //params.put("session_id", session_id);
        params.put("user_id", "rohan@jibe.com");
        params.put("question_id",  question_id);
        params.put("answer", answer);
        System.out.println(params);

        request = new OkHttpRequest(client);
        request.POST(url, params, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println(e);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(AnswersActivity.this, "Network issues. Answers.", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                try {
                    final String responseStr = response.body().string();
                    final JSONObject json = new JSONObject(responseStr);

                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                int valid = json.getInt("valid");
                                if (valid == 1) {
                                    System.out.println(responseStr);
                                    Toast.makeText(AnswersActivity.this, "Answer Added", Toast.LENGTH_SHORT).show();
                                    getAnswers();
                                    moveToEndOfList();

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }


    private void moveToEndOfList() {
        list.scrollToPosition(adapter.getItemCount());
    }


    /*private void postAnswerUpdates() {
        String likes = "";
        String dislikes = "";

        if(prefs.contains("answers_likes"))
            likes = prefs.getString("answers_likes","");

        if(prefs.contains("answers_likes"))
            dislikes = prefs.getString("answers_dislikes","");

        String session_id = prefs.getString("session_id","test_session_id");

        String url = getResources().getString(R.string.base_url) + "/answers/update.php";

        HashMap<String, String> params = new HashMap<>();
        params.put("session_id", session_id);
        params.put("user_id", "rohan@jibe.com");
        params.put("question_id",  question_id);
        params.put("answers_likes",  likes);
        params.put("answers_dislikes",  dislikes);

        System.out.println(params);

        request = new OkHttpRequest(client);
        request.POST(url, params, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println(e);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(AnswersActivity.this, "Network issues. Latest.", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                try {
                    final String responseStr = response.body().string();
                    final JSONObject json = new JSONObject(responseStr);

                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                int valid = json.getInt("valid");
                                if (valid == 1) {
                                    prefs.edit().remove("answers_likes").remove("answers_dislikes").apply();
                                    System.out.println(responseStr);
                                    Toast.makeText(AnswersActivity.this, "Answer Updated!!", Toast.LENGTH_SHORT).show();

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }
*/


    public void updateAnswerLike(String answer_id, String action) {
        String url = getResources().getString(R.string.base_url) + "/answers/update.php";
        String session_id = prefs.getString("session_id","test_session_id");
        HashMap<String, String> params = new HashMap<>();
        params.put("session_id", session_id);
        params.put("user_id", "rohan@jibe.com");
        params.put("action",  action);
        params.put("question_id",  question_id);
        params.put("answer_id", answer_id);

        System.out.println("Update Answer Like");
        System.out.println(params);

     /*   request = new OkHttpRequest(client);
        request.POST(url, params, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println(e);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(AnswersActivity.this, "Network issues. Answer Like.", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                try {
                    final String responseStr = response.body().string();
                    final JSONObject json = new JSONObject(responseStr);

                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                int valid = json.getInt("valid");
                                if (valid == 1) {
                                    Toast.makeText(AnswersActivity.this, "Answer Updated!!", Toast.LENGTH_SHORT).show();

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
*/
    }




    public void updateAnswerDislike(String answer_id, String action) {
        String url = getResources().getString(R.string.base_url) + "/answers/update.php";
        url = "http://192.168.0.102/myportablefiles/Jibe/app/answers/update.php";
        String session_id = prefs.getString("session_id","test_session_id");
        HashMap<String, String> params = new HashMap<>();
        params.put("session_id", session_id);
        params.put("user_id", "rohan@jibe.com");
        params.put("action",  action);
        params.put("question_id",  question_id);
        params.put("answer_id", answer_id);

        System.out.println("Update Answer Dislike");
        System.out.println(params);



      /*  request = new OkHttpRequest(client);
        request.POST(url, params, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println(e);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(AnswersActivity.this, "Network issues. Answer Like.", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                try {
                    final String responseStr = response.body().string();
                    final JSONObject json = new JSONObject(responseStr);

                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                int valid = json.getInt("valid");
                                if (valid == 1) {
                                    Toast.makeText(AnswersActivity.this, "Answer Updated!!", Toast.LENGTH_SHORT).show();

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });*/

    }
}

