package com.blackumor.jibe.Dashboard;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.blackumor.jibe.Externals.DashboardPagerAdapter;
import com.blackumor.jibe.Networking.OkHttpRequest;
import com.blackumor.jibe.Onboarding.JibeApplication;
import com.blackumor.jibe.Onboarding.LoginActivity;
import com.blackumor.jibe.Externals.SlidingTabLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;

import jibe.blackumor.com.jibe.R;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Response;

/**
 * Created by Rohan on 10-10-2015.
 */
public class DashboardActivity extends ActionBarActivity {

    private Toolbar toolbar;
    private ViewPager pager;
    private DashboardPagerAdapter adapter;
    private SlidingTabLayout mTabs;

    private FloatingActionButton create_question_fab;
    OkHttpClient client = new OkHttpClient();
    OkHttpRequest request;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        adapter = new DashboardPagerAdapter(getSupportFragmentManager(),
                DashboardActivity.this);

        pager = (ViewPager) findViewById(R.id.pager);
        pager.setOffscreenPageLimit(3);
        pager.setAdapter(adapter);
        toolbar = (Toolbar) findViewById(R.id.toolbar);


        setSupportActionBar(toolbar);
        mTabs = (SlidingTabLayout) findViewById(R.id.tabs);

        mTabs.setDistributeEvenly(true);
        mTabs.setViewPager(pager);


        create_question_fab = (FloatingActionButton) findViewById(R.id.fab);
        create_question_fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(DashboardActivity.this);
                LayoutInflater inflater = getLayoutInflater();
                final View create_question_dialog = inflater.inflate(R.layout.dialog_create_question, null);
                final EditText question = (EditText) create_question_dialog.findViewById(R.id.question);

                final Spinner spinner = (Spinner) create_question_dialog.findViewById(R.id.spinner);
                final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(DashboardActivity.this,
                        R.array.categories_array, android.R.layout.simple_spinner_item);

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(adapter);

                builder.setView(create_question_dialog);
                builder.setPositiveButton("Create", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        //Toast.makeText(DashboardActivity.this, "Question created!"+ question.getText().toString().trim(), Toast.LENGTH_SHORT).show();
                        publishQuestion("", question.getText().toString().trim(),String.valueOf(adapter.getItem(spinner.getSelectedItemPosition())));
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
                builder.create().show();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_dashboard, menu);
        return true;
    }

    @Override
    protected void onPause() {
        super.onPause();

        System.out.println("Dashboard Act on Pause.");
    }

    @Override
    public void onBackPressed() {
        JibeApplication jibeApplication = new JibeApplication();
        jibeApplication.invalidateDatabase();
        super.onBackPressed();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_login) {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void publishQuestion(String session_id, String question, String category) {
        String url = getResources().getString(R.string.base_url) + "/questions/create.php";

        HashMap<String, String> params = new HashMap<>();
        //params.put("session_id", session_id);
        params.put("user_id", "rohan@jibe.com");
        params.put("question",  question);
        params.put("category",  category);

        System.out.println(params);

        request = new OkHttpRequest(client);
        request.POST(url, params, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                try {
                    String responseStr = "";
                    final JSONObject json = new JSONObject(responseStr);
                    System.out.println(e);
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(DashboardActivity.this, "Network issues. Latest.", Toast.LENGTH_SHORT).show();
                            //new QuestionsResponse(getActivity()).parseLatest(LatestContentFragment.this, json);

                        }
                    });

                    //Intent intent = new Intent(.this, CategoriesListActivity.class);
                    //startActivity(intent);
                } catch (JSONException je) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                try {
                    String responseStr = response.body().string();
                    final JSONObject json = new JSONObject(responseStr);

                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                int valid = json.getInt("valid");
                                if (valid == 1) {
                                    //new QuestionsResponse(getActivity()).parseLatest(LatestContentFragment.this, json);
                                    Toast.makeText(DashboardActivity.this, "Question Added", Toast.LENGTH_SHORT).show();
                                    fetchLatest();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void fetchLatest() {
        adapter.getLatestContentFragment().fetchQuestions();
    }

    public void fetchTrending() {
        adapter.getTrendingFragment().fetchQuestions();
    }

    public void fetchInterested() {
        adapter.getInterestedFragment().fetchQuestions();
    }

}
