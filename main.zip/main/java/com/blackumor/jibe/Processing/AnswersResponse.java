package com.blackumor.jibe.Processing;


import android.content.Context;
import android.content.SharedPreferences;

import com.blackumor.jibe.Onboarding.JibeApplication;
import com.blackumor.jibe.Storage.AnswersDBAdapter;
import com.blackumor.jibe.Storage.FetchCompleteListener;
import com.blackumor.jibe.Storage.QuestionsDBAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * Created by Rohan on 18-10-2015.
 */
public class AnswersResponse {
    String id, question_id, user_id, title, time, likes, dislikes, user_image;
    String status = "0";
    JSONArray orderedkeys;
    JSONObject answers;
    private SharedPreferences prefs;
    String PREFS_NAME = "JibeTheApp";

    Context context;

    AnswersDBAdapter answersDBAdapter;

    public AnswersResponse(Context c) {
        context = c;
        orderedkeys = new JSONArray();
        answers = new JSONObject();
        answersDBAdapter = ((JibeApplication)c.getApplicationContext()).getAnswersDBAdapter();

        prefs = context.getSharedPreferences(PREFS_NAME, 0);
    }

    public void parseAnswers(FetchCompleteListener listener, JSONObject response) {
        try {
            String likes_string = prefs.getString("answers_likes", "");

            System.out.println(response);
            String dislikes_string = prefs.getString("answers_dislikes", "");

            System.out.println(prefs.getAll().toString());

            HashMap<String, String> status_map = new HashMap<>();

            if(!likes_string.equals("")) {
                JSONArray likes_array = new JSONArray(likes_string);
                for (int i = 0; i < likes_array.length(); i++)
                    status_map.put(likes_array.getString(i), "1");
            }

            if(!dislikes_string.equals("")) {
                JSONArray dislikes_array = new JSONArray(dislikes_string);
                for (int i = 0; i < dislikes_array.length(); i++)
                    status_map.put(dislikes_array.getString(i), "-1");
            }

            System.out.println(status_map);


            orderedkeys = new JSONArray();
            answers = new JSONObject();
            orderedkeys = response.getJSONArray("order");
            answers = response.getJSONObject("answers_details");
        //  response.remove("order");
            answersDBAdapter.invalidateAnswersDatabase();
            for(int i = 0 ; i < orderedkeys.length() ;  i ++) {
                String key = orderedkeys.getString(i);
                JSONObject tokens = answers.getJSONObject(key);
                id = tokens.getString("id");
                question_id = tokens.getString("question_id");
                user_id = tokens.getString("user_id");
                user_image = tokens.getString("user_image");
                title = tokens.getString("title");
                time = tokens.getString("timestamp");
                likes = tokens.getString("likes");
                dislikes = tokens.getString("dislikes");

                //if(likes_array)
                //status

                if(status_map.containsKey(id))
                    status = status_map.get(id);

                long success_id = answersDBAdapter.insertAnswersData(id, question_id, user_id,
                        user_image, title, time, likes, dislikes, status);
            }

            listener.fetchComplete();
        } catch (JSONException e) {
            System.out.println(e);
        }
    }

}
