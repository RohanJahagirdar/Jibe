package com.blackumor.jibe.Processing;


import android.content.Context;

import com.blackumor.jibe.Onboarding.JibeApplication;
import com.blackumor.jibe.Storage.FetchCompleteListener;

import com.blackumor.jibe.Storage.QuestionsDBAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


/**
 * Created by Rohan on 18-10-2015.
 */
public class QuestionsResponse {
    String id, user_id, user_name, title, time, likes, follows, answers, user_image;
    JSONArray orderedkeys;
    JSONObject questions, user_details;

    QuestionsDBAdapter questionsDBAdapter;

    public QuestionsResponse(Context c) {
        orderedkeys = new JSONArray();
        questions = new JSONObject();
        user_details = new JSONObject();
        questionsDBAdapter = ((JibeApplication)c.getApplicationContext()).getQuestionsDBAdapter();
    }

    public void parseLatest(FetchCompleteListener listener, JSONObject response) {
        try {
            orderedkeys = new JSONArray();
            questions = new JSONObject();
            orderedkeys = response.getJSONArray("order");
            questions = response.getJSONObject("questions_details");
            user_details = response.getJSONObject("user_details");
        //  response.remove("order");
          System.out.println(response);
            for(int i = 0 ; i < orderedkeys.length() ;  i ++) {
                String key = orderedkeys.getString(i);
                JSONObject tokens = questions.getJSONObject(key);
                id = tokens.getString("id");
                user_id = tokens.getString("user_id");
                user_name = user_details.getJSONObject(user_id).getString("name");
                user_image = user_details.getJSONObject(user_id).getString("image");
                title = tokens.getString("title");
                time = tokens.getString("timestamp");
                likes = tokens.getString("likes");
                follows = tokens.getString("follows");
                answers = tokens.getString("answers");


                long success_id = questionsDBAdapter.insertLatestQuestionsData(id, user_id, user_name,
                        user_image, title, time, likes, follows, answers);
//                if(success_id < 0) System.out.println("Failure");
 //               else System.out.println("Success");
            }

            listener.fetchComplete();
        } catch (JSONException e) {
            System.out.println("parseLatest" + e);
        }
    }

    public void parseTrending(FetchCompleteListener listener, JSONObject response) {
        try {
            orderedkeys = new JSONArray();
            questions = new JSONObject();
            orderedkeys = response.getJSONArray("order");
            questions = response.getJSONObject("questions_details");
            user_details = response.getJSONObject("user_details");
            //    response.remove("order");

            System.out.println(response);
            for(int i = 0 ; i < orderedkeys.length() ;  i ++) {
                String key = orderedkeys.getString(i);
                JSONObject tokens = questions.getJSONObject(key);
                id = tokens.getString("id");
                user_id = tokens.getString("user_id");
                user_name = user_details.getJSONObject(user_id).getString("name");
                user_image = user_details.getJSONObject(user_id).getString("image");
                title = tokens.getString("title");
                time = tokens.getString("timestamp");
                likes = tokens.getString("likes");
                follows = tokens.getString("follows");
                answers = tokens.getString("answers");

                long success_id =  questionsDBAdapter.insertTrendingQuestionsData(id, user_id, user_name,
                        user_image, title, time, likes, follows, answers);
      //          if(success_id < 0) System.out.println("Failure");
      //          else System.out.println("Success");

            }

            listener.fetchComplete();
        } catch (JSONException e) {
            System.out.println("parseTrending:  "+ e);
        }
    }


    public void parseInterested(FetchCompleteListener listener, JSONObject response) {

        try {
            orderedkeys = new JSONArray();
            questions = new JSONObject();

            orderedkeys = response.getJSONArray("order");
            questions = response.getJSONObject("questions_details");
            user_details = response.getJSONObject("user_details");
            //    response.remove("order");

            System.out.println(response);
            for(int i = 0 ; i < orderedkeys.length() ;  i ++) {
                String key = orderedkeys.getString(i);
                JSONObject tokens = questions.getJSONObject(key);
                id = tokens.getString("id");
                user_id = tokens.getString("user_id");
                user_name = user_details.getJSONObject(user_id).getString("name");
                user_image = user_details.getJSONObject(user_id).getString("image");
                title = tokens.getString("title");
                time = tokens.getString("timestamp");
                likes = tokens.getString("likes");
                follows = tokens.getString("follows");
                answers = tokens.getString("answers");

                long success_id =  questionsDBAdapter.insertInterestedQuestionsData(id, user_id, user_name,
                        user_image, title, time, likes, follows, answers);
            /*  long success_id =  questionsDBAdapter.insertInterestedQuestionsData(id, user_id, user_image, title, time, likes, follows, answers);
                if(success_id < 0) System.out.println("Failure");
                else System.out.println("Success");
            */
            }

            listener.fetchComplete();
        } catch (JSONException e) {
            System.out.println("parseInterestedterested: " + e);
        }
    }
}
