package com.blackumor.jibe.Onboarding;

import android.animation.ArgbEvaluator;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.blackumor.jibe.Externals.CirclePageIndicator;
import com.blackumor.jibe.Externals.SlidingTabLayout;
import com.blackumor.jibe.Externals.DashboardPagerAdapter;

import jibe.blackumor.com.jibe.R;

/**
 * Created by Rohan on 10-10-2015.
 */
public class OnboardActivity extends ActionBarActivity {

    private Toolbar toolbar;
    private ViewPager pager;
    private DashboardPagerAdapter adapter;
    private SlidingTabLayout mTabs;

    private static int [] colors;

    static final int num_images = 5;
    private ViewPager viewPager = null;
    private TextView continue_onboarding = null;
    private TextView onboarding_explanation = null;
    private ImageView logo;

    int back = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        setContentView(R.layout.activity_onboard);
        final ArgbEvaluator argbEvaluator = new ArgbEvaluator();

        colors = new int[5];
        colors[0] = getResources().getColor(R.color.onboarding_first);
        colors[1] = getResources().getColor(R.color.onboarding_second);
        colors[2] = getResources().getColor(R.color.onboarding_third);
        colors[3] = getResources().getColor(R.color.onboarding_fourth);
        colors[4] = getResources().getColor(R.color.onboarding_fifth);


        viewPager=(ViewPager) findViewById(R.id.pager);

        onboarding_explanation = (TextView)findViewById(R.id.onboarding_explanation);
        onboarding_explanation.setText(getResources().getText(R.string.onboarding_explanation));

        FragmentManager fm = getSupportFragmentManager();
        viewPager.setAdapter(new PagerAdapter(fm));

        CirclePageIndicator indicators = (CirclePageIndicator)findViewById(R.id.indicators);
        indicators.setViewPager(viewPager);

        indicators.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                if(position < (viewPager.getAdapter().getCount() -1) && position < (colors.length - 1)) {
                    viewPager.setBackgroundColor((Integer) argbEvaluator.evaluate(positionOffset, colors[position], colors[position + 1]));

                } else {
                    viewPager.setBackgroundColor(colors[colors.length - 1]);

                }
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        logo = (ImageView)findViewById(R.id.logo);
        logo.setBackgroundResource(R.drawable.jibe);

        continue_onboarding = (TextView)findViewById(R.id.continue_onboarding);
        continue_onboarding.setPaintFlags(continue_onboarding.getPaintFlags()|Paint.UNDERLINE_TEXT_FLAG);

        continue_onboarding.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OnboardActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

/*
        adapter = new TestPagerAdapter(getSupportFragmentManager(),
                OnboardActivity.this);

        pager = (ViewPager) findViewById(R.id.pager);
        pager.setAdapter(adapter);

        mTabs = (SlidingTabLayout) findViewById(R.id.tabs);

        mTabs.setDistributeEvenly(true);
        mTabs.setViewPager(pager);
*/
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_dashboard, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_login) {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    public class PagerAdapter extends FragmentPagerAdapter {
        public PagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public int getCount() {
            return num_images;
        }

        @Override
        public Fragment getItem(int i) {
            return CustomFragment.create(i);
        }
    }

    public static class CustomFragment extends Fragment {
        private int fragment_number, imageaddress;
        public static final String FRAG_NUM ="fragnum";
        private String [] text_description=null;
        RelativeLayout loginFragment, actions_layout;
        Button signUp, logIn, skip;
        Typeface condensedLight;

        public static CustomFragment create(int fragmentNumber) {
            CustomFragment fragment = new CustomFragment();
            Bundle args= new Bundle();
            args.putInt(FRAG_NUM, fragmentNumber);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            fragment_number = getArguments().getInt(FRAG_NUM);
        }

        @Override
        public View onCreateView(LayoutInflater inflater,ViewGroup container, Bundle savedInstanceState) {
            final FrameLayout layout = (FrameLayout) inflater.inflate(R.layout.page_viewer, container, false);
            ((ImageView) layout.findViewById(R.id.imageView)).
                    setBackgroundColor(colors[fragment_number]);

            return layout;
        }
    }
}
