package com.blackumor.jibe.Onboarding;

import android.annotation.TargetApi;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.blackumor.jibe.Dashboard.DashboardActivity;
import com.blackumor.jibe.Networking.OkHttpRequest;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.regex.Pattern;

import jibe.blackumor.com.jibe.R;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Response;

@TargetApi(Build.VERSION_CODES.LOLLIPOP)
public class LoginActivity extends ActionBarActivity{

    Toolbar toolbar;
    EditText email, password, nickname;
    ImageView user_dp, m_1, m_2, m_3, m_4, m_5, w_1, w_2, w_3, w_4, w_5;
    GridLayout gridLayout;

    TextView retain_theme;

    private Button done;
    private Pattern pattern;
//    private Toast toast;
    int profile_character = 0;


    OkHttpClient client = new OkHttpClient();
    OkHttpRequest request;
    private SharedPreferences prefs;
    String PREFS_NAME = "JibeTheApp";
    JibeApplication jibeApplication;

    private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
            + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    Window window;
//    Picasso picasso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        prefs = getSharedPreferences(PREFS_NAME, 0);


        window = getWindow();

        jibeApplication = new JibeApplication();

        pattern = Pattern.compile(EMAIL_PATTERN);


        email = (EditText)findViewById(R.id.email);
        password = (EditText)findViewById(R.id.password);
        nickname = (EditText)findViewById(R.id.nickname);

        if(prefs.contains("email") && prefs.contains("pass")) {
            email.setText(prefs.getString("email", ""));
            password.setText(prefs.getString("pass", ""));
        }

        if(prefs.contains("nickname") ) {
            nickname.setText(prefs.getString("nickname", ""));
        }



        retain_theme = (TextView)findViewById(R.id.retain_theme);

        done = (Button)findViewById(R.id.done);
        gridLayout = (GridLayout)findViewById(R.id.gridLayout);

        user_dp  = (ImageView)findViewById(R.id.profile_image);

        m_1 = (ImageView)findViewById(R.id.m_1);
        m_2 = (ImageView)findViewById(R.id.m_2);
        m_3 = (ImageView)findViewById(R.id.m_3);
        m_4 = (ImageView)findViewById(R.id.m_4);
        m_5 = (ImageView)findViewById(R.id.m_5);

        w_1 = (ImageView)findViewById(R.id.w_1);
        w_2 = (ImageView)findViewById(R.id.w_2);        w_3 = (ImageView)findViewById(R.id.w_3);


        w_4 = (ImageView)findViewById(R.id.w_4);
        w_5 = (ImageView)findViewById(R.id.w_5);

        retain_theme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    window.setStatusBarColor(getResources().getColor(R.color.ColorPrimaryDark));
                    getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.ColorPrimary)));
                    //    gridLayout.setBackgroundColor(getResources().getColor(R.color.m1ColorPrimary));
                }
            }
        });

        m_1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                user_dp.setBackgroundResource(R.drawable.m_1);
                profile_character = 0;
                setTheme(R.style.m1Theme);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    window.setStatusBarColor(getResources().getColor(R.color.m1ColorPrimaryDark));
                    getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.m1ColorPrimary)));
                //    gridLayout.setBackgroundColor(getResources().getColor(R.color.m1ColorPrimary));
                }
            }
        });

        m_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user_dp.setBackgroundResource(R.drawable.m_2);
                profile_character = 1;
                setTheme(R.style.m2Theme);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    window.setStatusBarColor(getResources().getColor(R.color.m2ColorPrimaryDark));
                    getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.m2ColorPrimary)));
                //    gridLayout.setBackgroundColor(getResources().getColor(R.color.m2ColorPrimary));
                }
            }
        });

        m_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user_dp.setBackgroundResource(R.drawable.m_3);
                profile_character = 2;
                setTheme(R.style.m3Theme);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    window.setStatusBarColor(getResources().getColor(R.color.m3ColorPrimaryDark));
                    getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.m3ColorPrimary)));
                 //   gridLayout.setBackgroundColor(getResources().getColor(R.color.m3ColorPrimary));
                }
            }
        });

        m_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user_dp.setBackgroundResource(R.drawable.m_4);
                profile_character = 3;
                setTheme(R.style.m4Theme);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    window.setStatusBarColor(getResources().getColor(R.color.m4ColorPrimaryDark));
                    getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.m4ColorPrimary)));
                 //   gridLayout.setBackgroundColor(getResources().getColor(R.color.m4ColorPrimary));
                }
            }
        });

        m_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user_dp.setBackgroundResource(R.drawable.m_5);
                profile_character = 4;
                setTheme(R.style.m5Theme);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    window.setStatusBarColor(getResources().getColor(R.color.m5ColorPrimaryDark));
                    getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.m5ColorPrimary)));
                //    gridLayout.setBackgroundColor(getResources().getColor(R.color.m5ColorPrimary));






                }
            }
        });



        w_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user_dp.setBackgroundResource(R.drawable.w_1);
                profile_character = 5;
                setTheme(R.style.w1Theme);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    window.setStatusBarColor(getResources().getColor(R.color.w1ColorPrimaryDark));
                    getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.w1ColorPrimary)));
                 //   gridLayout.setBackgroundColor(getResources().getColor(R.color.w1ColorPrimary));
                }
            }
        });

        w_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user_dp.setBackgroundResource(R.drawable.w_2);
                profile_character = 6;
                setTheme(R.style.w2Theme);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    window.setStatusBarColor(getResources().getColor(R.color.w2ColorPrimaryDark));
                    getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.w2ColorPrimary)));
                //    gridLayout.setBackgroundColor(getResources().getColor(R.color.w2ColorPrimary));
                }
            }
        });

        w_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user_dp.setBackgroundResource(R.drawable.w_3);
                profile_character = 7;
                setTheme(R.style.w3Theme);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
        2            window.setStatusBarColor(getResources().getColor(R.color.w3ColorPrimaryDark));
                    getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.w3ColorPrimary)));
                 //   gridLayout.setBackgroundColor(getResources().getColor(R.color.w3ColorPrimary));
                }
            }
        });

        w_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user_dp.setBackgroundResource(R.drawable.w_4);
                profile_character = 8;
                setTheme(R.style.w4Theme);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    window.setStatusBarColor(getResources().getColor(R.color.w4ColorPrimaryDark));
                    getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.w4ColorPrimary)));
                //    gridLayout.setBackgroundColor(getResources().getColor(R.color.w4ColorPrimary));
                }
            }
        });

        w_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user_dp.setBackgroundResource(R.drawable.w_5);
                profile_character = 9;
                setTheme(R.style.w5Theme);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    window.setStatusBarColor(getResources().getColor(R.color.w5ColorPrimaryDark));
                    getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.w5ColorPrimary)));
                //    gridLayout.setBackgroundColor(getResources().getColor(R.color.w5ColorPrimary));
                }
            }
        });

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user_email = email.getText().toString();
                String user_password = password.getText().toString();
                String user_nickname = nickname.getText().toString();
                if(validate(user_email, user_password)) {
                    login(user_email, user_password, user_nickname, String.valueOf(profile_character));
                }
        //        Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
        //        startActivity(intent);
         /*       Toast.makeText(LoginActivity.this, "Login process started", Toast.LENGTH_SHORT).show();
                String user_email = email.getText().toString();
                String user_password = password.getText().toString();
                String user_nickname = nickname.getText().toString();
                if(validate(user_email, user_password)) {
                    updateUserDetails(user_email, user_password, user_nickname, String.valueOf(profile_character));
                }
         */
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_login, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        if( id == android.R.id.home) {
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void updateUserDetails(String email, String password, String nickname, String profile_character) {

        String url = getResources().getString(R.string.account_base_url) + "/updateUserDetails.php";


        HashMap<String, String> params = new HashMap<String, String>();
        params.put("email", email);
        params.put("password", password);
        params.put("profile_character", profile_character);
        params.put("nickname", nickname);

        request = new OkHttpRequest(client);

        request.POST(url, params, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println(e);
                Toast.makeText(LoginActivity.this, "Login Failure!!", Toast.LENGTH_SHORT).show();
              //  Intent intent = new Intent(LoginActivity.this, CategoriesListActivity.class);
              //  startActivity(intent);

            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            String responseStr = response.body().string();
                        //    System.out.println(responseStr);
                            JSONObject json = new JSONObject(responseStr);
                            int valid = json.getInt("valid");
                            if (valid == 1) {
                                String email = json.getString("user");
                                String pass = json.getString("pass");
                                String session_id = json.getString("id");
                                String likes = json.getString("likes");
                                String dislikes = json.getString("dislikes");
                                String nickname = json.getString("nickname");
                                prefs.edit().putString("email", email).putString("pass", pass).putString("nickname", nickname).
                                        putString("session_id", session_id).putString("likes", likes).
                                        putString("dislikes", dislikes).apply();
                                Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                                startActivity(intent);
                            } else {
                                //    prefs.edit().remove("email").remove("pass").
                                //            remove("session_id").apply();
                                Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                                startActivity(intent);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });
    }


    private void login(String email, String password, String nickname, String profile_character) {

        String url = getResources().getString(R.string.account_base_url) + "/login.php";


        HashMap<String, String> params = new HashMap<String, String>();
        params.put("email", email);
        params.put("password", password);
        params.put("profile_character", profile_character);
        params.put("nickname", nickname);

        request = new OkHttpRequest(client);

        request.POST(url, params, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                System.out.println(e);
                Toast.makeText(LoginActivity.this, "Login Failure!!", Toast.LENGTH_LONG).show();
                //  Intent intent = new Intent(LoginActivity.this, CategoriesListActivity.class);
                //  startActivity(intent);

            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            String responseStr = response.body().string();
                                System.out.println(responseStr);
                            JSONObject json = new JSONObject(responseStr);
                            int valid = json.getInt("valid");
                            if (valid == 1) {
                                String email = json.getString("user");
                                String pass = json.getString("pass");
                                String session_id = json.getString("id");
                                String answers_likes = json.getString("answers_likes");
                                String answers_dislikes = json.getString("answers_dislikes");

                                String questions_likes = json.getString("questions_likes");
                                String questions_dislikes = json.getString("questions_dislikes");

                                String nickname = json.getString("nickname");
                                String profile_character = json.getString("profile_character");
                                prefs.edit().putString("email", email).putString("pass", pass).
                                        putString("session_id", session_id).
                                        putString("nickname", nickname).
                                        putString("profile_character", profile_character).
                                        putString("answers_likes", answers_likes).
                                        putString("answers_dislikes", answers_dislikes).
                                        putString("questions_likes", questions_likes).
                                        putString("questions_dislikes", questions_dislikes).apply();
                                Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                                startActivity(intent);
                            } else {
                                //    prefs.edit().remove("email").remove("pass").
                                //            remove("session_id").apply();
                                Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                                startActivity(intent);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });


    }

    private boolean validate(String email, String password) {
        if (!pattern.matcher(email).matches()) {
            Toast.makeText(LoginActivity.this, "Please enter a valid email id.", Toast.LENGTH_LONG).show();
            return false;
        } else if (password.length() == 0 || password.length() < 4) {
            Toast.makeText(LoginActivity.this, "Please enter a valid password.", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }


}


















































































