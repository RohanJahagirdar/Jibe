package com.blackumor.jibe.Onboarding;

import android.app.Application;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.ImageView;

import com.blackumor.jibe.Storage.AnswersDBAdapter;
import com.blackumor.jibe.Storage.QuestionsDBAdapter;

import jibe.blackumor.com.jibe.R;


/**
 * Created by Rohan on 10-10-2015.
 */
public class JibeApplication extends Application {

    private QuestionsDBAdapter questionsDBAdapter;
    private AnswersDBAdapter answersDBAdapter;

    @Override
    public void onCreate() {
        super.onCreate();
        questionsDBAdapter = new QuestionsDBAdapter(this);
        questionsDBAdapter.initialize(this);
        questionsDBAdapter.invalidateTrendingQuestionsDatabase();
        questionsDBAdapter.invalidateLatestQuestionsDatabase();
        questionsDBAdapter.invalidateInterestedQuestionsDatabase();

        answersDBAdapter = new AnswersDBAdapter(this);
        answersDBAdapter.initialize(this);
        answersDBAdapter.invalidateAnswersDatabase();
    }

    public void invalidateDatabase(){
        if(questionsDBAdapter == null) {
            questionsDBAdapter = new QuestionsDBAdapter(this);
        //    questionsDBAdapter.initialize(this);
        //    questionsDBAdapter.invalidateTrendingQuestionsDatabase();
         //   System.out.println("questionsDBAdapter is null");
        } else {
            System.out.println("questionsDBAdapter is NOT null");
            questionsDBAdapter.invalidateTrendingQuestionsDatabase();
            questionsDBAdapter.invalidateLatestQuestionsDatabase();
            questionsDBAdapter.invalidateInterestedQuestionsDatabase();
        }
    }

    public QuestionsDBAdapter getQuestionsDBAdapter() {return  questionsDBAdapter;}

    public AnswersDBAdapter getAnswersDBAdapter() {return  answersDBAdapter;}

    public boolean isNetworkAvailable() {
        ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = manager.getActiveNetworkInfo();
        if (info != null && info.isAvailable())
            return true;
        else
            return false;
    }


    public void  setCreatorImage(int image_id, ImageView creator_imageview){
        switch (image_id){
            case 1:
                creator_imageview.setBackgroundResource(R.drawable.m_1);
                break;
            case  2:
                creator_imageview.setBackgroundResource(R.drawable.m_2);
                break;
            case  3:
                creator_imageview.setBackgroundResource(R.drawable.m_3);
                break;
            case  4:
                creator_imageview.setBackgroundResource(R.drawable.m_4);
                break;
            case  5:
                creator_imageview.setBackgroundResource(R.drawable.m_5);
                break;

            case  6:
                creator_imageview.setBackgroundResource(R.drawable.w_1);
                break;
            case  7:
                creator_imageview.setBackgroundResource(R.drawable.w_2);
                break;
            case  8:
                creator_imageview.setBackgroundResource(R.drawable.w_3);
                break;
            case  9:
                creator_imageview.setBackgroundResource(R.drawable.w_4);
                break;
            case  10:
                creator_imageview.setBackgroundResource(R.drawable.w_5);
                //    Picasso.with(context).load(R.drawable.w_5).into(creator_imageview);
                //    Picasso.with(getActivity()).load(R.drawable.bakery).transform(new CircleTransform()).into(category_4_image_view);
                break;

            default:
                creator_imageview.setBackgroundResource(R.drawable.m_2);
                break;
        }
    }
}
